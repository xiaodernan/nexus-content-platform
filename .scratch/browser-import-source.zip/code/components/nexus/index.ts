// 由 NEXUS 从设计模型生成。页面组件可以在 Studio 的代码视图里改，应用后写回模型；解析不了的片段会在下一次生成时被模型覆盖（§19）
import { Home } from "./Home";

export const nexusPages = [
  { name: "Home", route: "/home", component: Home },
];
