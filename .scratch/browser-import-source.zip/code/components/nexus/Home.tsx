// 由 NEXUS 从设计模型生成。页面组件可以在 Studio 的代码视图里改，应用后写回模型；解析不了的片段会在下一次生成时被模型覆盖（§19）
export function Home() {
  return (
    <main className="w-[1440px] h-[900px] flex flex-col justify-start items-start bg-[var(--nx-color-background)]" data-nexus-id="fra_mvhemphipwb3qn">
      <section className="self-stretch flex flex-col gap-[var(--nx-space-6)] pt-[var(--nx-space-16)] pr-[var(--nx-space-8)] pb-[var(--nx-space-16)] pl-[var(--nx-space-8)] justify-start items-start bg-[var(--nx-color-surface)]" data-nexus-id="sec_mvhemphil4swcy">
        <p className="w-fit font-[family-name:var(--nx-font-mono)] text-[12px] font-medium leading-[1.5] tracking-[2px] whitespace-pre text-[var(--nx-color-accent)]" data-nexus-id="tex_mvhemphiu5xkku">
          NEXUS STUDIO
        </p>
        <h1 className="self-stretch font-[family-name:var(--nx-font-heading)] text-[56px] font-bold leading-[1.1] tracking-[-1.5px] whitespace-pre-wrap text-[var(--nx-color-text)]" data-nexus-id="tex_mvhemphipruf91">
          从一句话到一个可发布的产品
        </h1>
        <p className="self-stretch font-[family-name:var(--nx-font-body)] text-[18px] font-normal leading-[1.6] whitespace-pre-wrap text-[var(--nx-color-text-muted)]" data-nexus-id="tex_mvhemphihwgm92">
          画布、代码与预览都是同一份设计模型的投影。改模型，三处一起更新。
        </p>
        <div className="w-fit flex flex-row gap-[var(--nx-space-3)] justify-start items-center" data-nexus-id="con_mvhemphi42yedi">
          <button type="button" className="h-fit flex flex-row pt-[var(--nx-space-3)] pr-[var(--nx-space-6)] pb-[var(--nx-space-3)] pl-[var(--nx-space-6)] justify-start items-start bg-[var(--nx-color-primary)] rounded-[var(--nx-radius-md)] font-[family-name:var(--nx-font-body)] text-[15px] font-semibold leading-[1.5] text-center whitespace-pre text-[var(--nx-color-on-primary)]" data-nexus-id="but_mvhemphinfdtr2">
            开始设计
          </button>
          <button type="button" className="h-fit flex flex-row pt-[var(--nx-space-3)] pr-[var(--nx-space-6)] pb-[var(--nx-space-3)] pl-[var(--nx-space-6)] justify-start items-start rounded-[var(--nx-radius-md)] border-[1px] border-[var(--nx-color-border)] font-[family-name:var(--nx-font-body)] text-[15px] font-medium leading-[1.5] text-center whitespace-pre text-[var(--nx-color-text)]" data-nexus-id="but_mvhemphiujmt8q">
            查看文档
          </button>
        </div>
      </section>
    </main>
  );
}
